"use strict";// Не ищем легкий путей
alert ("Привет, Javascript");
